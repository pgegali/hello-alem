package main

import "github.com/01-edu/z01"

func main() {
	z01.PrintRune('0')
	z01.PrintRune('1')
	z01.PrintRune('2')
	z01.PrintRune('3')
	z01.PrintRune('4')
	z01.PrintRune('5')
	z01.PrintRune('6')
	z01.PrintRune('7')
	z01.PrintRune('8')
	z01.PrintRune('9')
	z01.PrintRune('\n')
}
