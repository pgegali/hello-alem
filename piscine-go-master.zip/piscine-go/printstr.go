package piscine

import "github.com/01-edu/z01"

func PrintStr(s string) {
	z := []rune(s)
	for _, x := range z {
		z01.PrintRune(x)
	}
}
