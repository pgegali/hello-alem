#!bin/bash
num=$( head -n 179 streets/Buckingham_Place | tail -n 1 | sed s/[^0-9]//g)
echo $num
cat interviews/interview-$num
echo $MAIN_SUSPECT
