package main

import "github.com/01-edu/z01"

func main() {
	z01.PrintRune('a')
	z01.PrintRune('b')
	z01.PrintRune('c')
	z01.PrintRune('d')
	z01.PrintRune('e')
	z01.PrintRune('f')
	z01.PrintRune('g')
	z01.PrintRune('h')
	z01.PrintRune('i')
	z01.PrintRune('j')
	z01.PrintRune('k')
	z01.PrintRune('l')
	z01.PrintRune('m')
	z01.PrintRune('n')
	z01.PrintRune('o')
	z01.PrintRune('p')
	z01.PrintRune('q')
	z01.PrintRune('r')
	z01.PrintRune('s')
	z01.PrintRune('t')
	z01.PrintRune('u')
	z01.PrintRune('v')
	z01.PrintRune('w')
	z01.PrintRune('x')
	z01.PrintRune('y')
	z01.PrintRune('z')
	z01.PrintRune('\n')
}
