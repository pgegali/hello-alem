package piscine

func UltimatePointOne(n ***int) {
	***n = 1
}
