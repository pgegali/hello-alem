ls -l | sed '1!n;d'
